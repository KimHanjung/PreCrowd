//5

import React, { useState, Component } from 'react'
import axios from 'axios';
import Select from 'react-select';
class Submit_page extends React.Component{

    constructor(props) {
        super(props);
        this.state = {
            checked: false,
            error: false,
            Loading:false,

            task_name: this.props.location.state.taskname,
            type_name: null,
            type_list: [],
            my_list: [],
            round: null,
            period: null,
            selectedFile: null,
        };
        this.handleTypename = this.handleTypename.bind(this)
        this.handleRound = this.handleRound.bind(this)
        this.handlePeriod = this.handlePeriod.bind(this)
        this.handleFileInput = this.handleFileInput.bind(this)
    }
    componentDidMount(){
        this.fetchType();
    }
    fetchType = async () => {
        axios.get("/src/api/typelist",{
            params:{
                task_name: this.state.task_name
            }
        })
        .then(( response ) => {
            console.log(response.data[0].Type_name);
          this.setState({ 
            type_list: response.data
          }, () => {
            const copy_list =[];
            this.setState({my_list: []});
            var x =0;
            console.log(this.state.type_list);
            while(x<this.state.type_list.length){
                var task_name = this.state.type_list[x].Task_name;
                copy_list.push(
                    <option value ={task_name}>hi</option>
                )
                x=x+1;
            }
            this.setState({my_list: copy_list}, () => {
            console.log(this.state.my_list);
            this.setState({
                Loading: true,
            });
            })
          });
        })
        .catch(e => {
          console.error(e);
        });

        
    };


    handleTypename(e){
        this.setState({
            type_name: e.target.value
        })
    }
    handleRound(e){
        this.setState({
            round: e.target.value
        })
    }
    handlePeriod(e){
        this.setState({
            period: e.target.value
        })
    }
    handleFileInput(e){
        this.setState({
          selectedFile : e.target.files[0],
        })
      }
    

    handlePost=()=> {
        const Myuser = JSON.parse(localStorage.getItem("user"));
        const user_id = Myuser.id;
        const type_name = this.state.type_name;
        const task_name = this.state.task_name;
        const round = this.state.round;
        const period = this.state.period;
        const userfile = this.state.userfile;

        return axios.post("/src/api/submit", {
            user_id,
            type_name,
            task_name,
            round,
            period,
            userfile
        }).then(res => {
            alert('success')
        }).catch(err => {
            alert('fails')
        })
    }

    render(){
        return (
            <div>
                <h1>{this.state.task_name}, hello</h1>
                <Select name ="task" value={this.state.type_name} onChange={this.handleTypename}>
                  <option value = "">Task_List</option>
                  <option value = "a">ask_List</option>

                </Select>
                <input type="file" name="file" onChange={e => this.handleFileInput(e)} />
                <input type="text" name="Round" onChange={(e) => this.handleRound(e)} />
                <input type="text" name="Duration" onChange={(e) => this.handleDuration(e)}/>
                <button type="button" onClick={() => this.handlePost()} > Submit? </button>

                <Form onSubmit={handleRegister} ref={form}>
                    {!successful && (
                        <div>
                        <div className="form-group">
                            <label htmlFor="username">Username</label>
                            <Input
                            type="text"
                            className="form-control"
                            name="username"
                            value={username}
                            onChange={onChangeUsername}
                            validations={[required, vusername]}
                            />
                        </div>

                        <div className="form-group">
                            <label htmlFor="Id">Id</label>
                            <Input
                            type="text"
                            className="form-control"
                            name="Id"
                            value={id}
                            onChange={onChangeId}
                            validations={[required, validId]}
                            />
                        </div>

                        <div className="form-group">
                            <label htmlFor="password">Password</label>
                            <Input
                            type="password"
                            className="form-control"
                            name="password"
                            value={password}
                            onChange={onChangePassword}
                            validations={[required, vpassword]}
                            />
                        </div>

                        <div className="form-group">
                            <label htmlFor="address">Address</label>
                            <Input
                            type="text"
                            className="form-control"
                            name="address"
                            value={address}
                            onChange={onChangeAddress}
                            validations={[required]}
                            />
                        </div>

                        <div className="form-group">
                            <label htmlFor="gender">Gender<br/></label>
                            <Select name='gender' value={gender} validations={[required]} onChange={onChangeGender}>
                            <option value=''>Gender</option>
                            <option value='M'>Male</option>
                            <option value='F'>Female</option>
                            </Select>
                        </div>

                        <div className="form-group">
                            <label htmlFor="bdate">Birthday</label>
                            <Input
                            type="text"
                            className="form-control"
                            name="bdate"
                            placeholder = "YYYYMMDD"
                            value={bdate}
                            onChange={onChangeBdate}
                            validations={[required, vbdate]}
                            />
                        </div>

                        <div className="form-group">
                            <label htmlFor="phone">Phone</label>
                            <Input
                            type="text"
                            className="form-control"
                            name="phone"
                            placeholder = "xxx-xxxx-xxxx"
                            value={phone}
                            onChange={onChangePhone}
                            validations={[required, vphone]}
                            />
                        </div>

                        <div className="form-group">
                            <label htmlFor="role">Role<br/></label>
                            <Select name='role' value={role} validations={[required]} onChange={onChangeRole}>
                            <option value=''>Choose your role</option>
                            <option value='Submittor'>Submittor</option>
                            <option value='Evaluationer'>Evaluationer</option>
                            </Select>
                        </div>

                        <div className="form-group">
                            <button className="btn btn-primary btn-block">Sign Up</button>
                        </div>
                        </div>
                    )}

                    {message && (
                        <div className="form-group">
                        <div
                            className={ successful ? "alert alert-success" : "alert alert-danger" }
                            role="alert"
                        >
                            {message}
                        </div>
                        </div>
                    )}
                    <CheckButton style={{ display: "none" }} ref={checkBtn} />
                    </Form>
            </div>
        )
    }
    
    
}

export default Submit_page;